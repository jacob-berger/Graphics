#version 430 core

out vec4 fColor;

void main(){


     fColor = vec4(0.65, 0.25, 0.8, 1.0);
}

